from Start_screen import StartScreen
from Tetris import Tetris


START_SCREEN = 0
MAIN_SCREEN = 1


class GameMain:
    def __init__(self, fps, screen):
        self.screen = screen
        self.fps = fps
        self.state = START_SCREEN
        self.scenes = [StartScreen(self.next_scene, self.screen), Tetris(self.fps, self.screen)]

    def draw(self, dt=None):
        self.get_active_scene().draw(dt)

    def get_active_scene(self):
        return self.scenes[self.state]

    def next_scene(self):
        self.state += 1

    def on_event(self, event):
        self.get_active_scene().on_event(event)
