from Start_screen import StartScreen
from Tetris import Tetris


START_SCREEN = 0
MAIN_SCREEN = 1


class GameMain:
    def __init__(self, fps, screen):
        self.screen = screen
        self.fps = fps
        self.state = START_SCREEN
        self.scenes = [StartScreen(self.next_scene), Tetris(self.fps, self.screen)]

    def draw(self, dt=None):
        if self.state == 0:
            StartScreen(self.next_scene).draw(dt)
        else:
            Tetris(self.fps, self.screen).render(self.screen)
            Tetris(self.fps, self.screen).draw_buttons(self.screen)

    def get_active_scene(self):
        return self.scenes[self.state]

    def next_scene(self):
        self.state += 1

    def on_event(self, event):
        self.get_active_scene().on_event(event)
