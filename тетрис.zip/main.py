import pygame
from Tetris import Tetris
from GameMain import GameMain
if __name__ == '__main__':
    pygame.init()
    pygame.display.set_caption('')
    width, height = 750, 900
    size = width, height
    screen = pygame.display.set_mode(size)
    clock = pygame.time.Clock()
    fps = 60
    dt = 0
    running = True
    tetris = Tetris(fps, screen)
    game = GameMain(fps, screen)
    while running:
        for event in pygame.event.get():
            game.on_event(event)
            if event.type == pygame.QUIT:
                running = False
            if event.type == pygame.KEYDOWN:
                tetris.on_key_pressed(event.key, screen)
            if event.type == pygame.MOUSEBUTTONDOWN:
                tetris.get_click(event.pos)
        screen.fill(pygame.Color('gray'))
        game.draw(dt)
        tetris.update_figure(screen)
        pygame.display.flip()
        clock.tick(fps)
    pygame.quit()
